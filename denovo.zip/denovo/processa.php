<?php

include_once = ("config.php");

$nome = filter_input(input_POST, 'nome', filter_sanitize_string);
$email = filter_input(input_POST, 'email', filter_sanitize_email);
$password = filter_input(input_POST, 'password', filter_sanitize_string);

$result_eu = "INSERT INTO  eu ('nome, 'email', 'password') VALUES ('$nome', '$email', '$password')";
$resultado_eu = mysqli_query($conn, $result_eu);

