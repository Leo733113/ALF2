<?php
session_start();
?>
 
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Bem vindo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <h1 class="my-5">Oi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b><p> Bem vindo ao nosso site. <br>Ainda não está disponível a área para usuários.<br> Assim que estiver pronta mandamos um Feedback. obrigado!</p></h1>
    <p>
        <a href="https://sistemajak.top/hospedagem.html" class="btn btn-warning">Hospedar site</a>
        <a href="https://sistemajak.top/sites.html" class="btn btn-danger ml-3">Obter site</a>
		<a href="https://sistemajak.top/marketing-digital.html" class="btn btn-danger ml-3">Expandir site</a>
    </p>
</body>
</html>