<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Cristiane Faria | Formulário PHP</title>
    </head>
    <body>
       <h1> cadastrar usuario </h1>

       <form method="post" action="processa.php">
           <label>Nome:</label>
           <input type="text" name="nome" placeholder="digite o nome completo"><BR>
           <label>Email:</label>
           <input type="text" name="email" placeholder="digite o seu email"><BR>
           <label>Password:</label>
           <input type="text" name="password" placeholder="digite a sua palavra pass"><BR>
<input type="submit" value="cadastrar">
        </form>
    </body>
</html>
